import javax.swing.JFrame;

public class Start  {
	//creates new OptionFrame
	public static void main(String[] args) {
		JFrame obFrame = new OptionsFrame();
	}
}
