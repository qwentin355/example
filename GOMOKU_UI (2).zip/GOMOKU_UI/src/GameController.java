import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class GameController extends JFrame implements ActionListener
{
	int [][] naBoard;
	private JPanel obPanel;
	private JButton[][] oaButtonArray;
	private JButton obButton;
	int nPlayerCount =1;
	int [] naUser;
	int  nPlayerToken = 2;

	//sets Frame parameters
	public GameController(int nGridSize,int nPlayer) 
	{
		nPlayerCount = nPlayer;
		createPanel(nGridSize);
		setSize(nGridSize*50,nGridSize*50);
		setTitle("Gomoku");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	/*
	 * builds fills GridLayout with elements from
	 * oaButtonArray each element is given a name and 
	 * a listener
	 */
	private void createPanel(int nGridSize)
	{
		naBoard = new int[nGridSize][nGridSize];

		oaButtonArray = new JButton[nGridSize][nGridSize];
		obPanel = new JPanel();
		obPanel.setBorder(new EmptyBorder(5,5,5,5));
		obPanel.setLayout(new GridLayout(nGridSize,nGridSize));		

		for(int i=0;i<oaButtonArray.length;i++)
		{
			for(int j = 0;j<oaButtonArray[i].length;j++)
			{
				obButton = oaButtonArray[i][j];
				obButton = new JButton();
				obButton.setName(String.valueOf(i)+":"+String.valueOf(j));
				obButton.addActionListener(this);

				obPanel.add(obButton);
			}
		}
		add(obPanel);
	}
	/*
	 * handles button presses changes color depending on nPlayerToken
	 * removes listener, sets naUser = to button name, passes naUser
	 * to Update board
	 */
	public void actionPerformed(ActionEvent event)
	{
		nPlayerToken = GomokuGameLogic.PlayerToken(nPlayerToken);
		//Updates obButton colors and removes listener
		if(nPlayerToken == 1)
		{
			((JButton) event.getSource()).setBackground(Color.BLACK);
			((JButton) event.getSource()).removeActionListener(this);
			String [] UserString = (((JButton) event.getSource()).getName().split(":"));
			naUser = userInput(UserString);
		}
		else if(nPlayerToken ==2)
		{
			((JButton) event.getSource()).setBackground(Color.RED);
			((JButton) event.getSource()).removeActionListener(this);
			String [] UserString = (((JButton) event.getSource()).getName().split(":"));
			naUser = userInput(UserString);
		}

		//updates naBoard and checks for win condition
		naBoard = GomokuGameLogic.Update(naBoard, naUser, nPlayerToken);
		
		if(winCheck())
			return;
		//AI exception
		if(nPlayerCount==2)
		{
			naUser = AIBoardController(naUser, naBoard);
			nPlayerToken = GomokuGameLogic.PlayerToken(nPlayerToken);
			naBoard = GomokuGameLogic.Update(naBoard, naUser, nPlayerToken);
			if(winCheck())
				return;
		}
	}
	
	//check win condition, ends game if true
	private boolean winCheck()
	{
		if(GomokuGameLogic.WinCondition(GomokuGameLogic.ColCheck(naBoard), GomokuGameLogic.RowCheck(naBoard),
				GomokuGameLogic.DiagCheck(naBoard)))
		{
			GameWin();
			return true;
		}
		return false;
	}
	//AI board communicator
	private int[] AIBoardController(int[] naUser, int[][] naBoard)
	{
		AIController AI = new AIController();
		Component[] comp = obPanel.getComponents();
		String Computer = AI.AIController(naUser, naBoard);
		String[] CompChoice = null;

		for (int i = 0;comp.length>i;i++)
		{
			if (comp[i] instanceof JButton)
			{
				if(comp[i].getName().equals(Computer))
				{
					comp[i].setBackground(Color.green);
					((JButton)comp[i]).removeActionListener(this);
					CompChoice = comp[i].getName().split(":");
				}
			}
		}
		return userInput(CompChoice);
	}

	//converts string array to int array
	private int[] userInput(String [] UserString)
	{
		naUser = new int[UserString.length];
		for(int i = 0;i<UserString.length;i++)
		{
			naUser[i] =Integer.parseInt(UserString[i]);
		}
		return naUser;
	}

	//creates an optionpane to display game winner 
	private void GameWin()
	{
		JFrame obWinFrame = new JFrame(); 
		JOptionPane.showMessageDialog(obWinFrame,"Player "+nPlayerToken+ " Wins");
		setVisible(false);
	}
	//creates optionpane to display stalemate
	// referenced in GomokuGameLogic.java
	public static void StaleMate()
	{
		JFrame obWinFrame = new JFrame(); 
		JOptionPane.showMessageDialog(obWinFrame,"Draw");
	}
}

