import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class OptionsFrame extends JFrame   {
	private int nSize = 250;
	private int Players = 2;;
	//Sets frame parameters
	public OptionsFrame() 
	{
		createPanel();
		setSize(nSize,nSize/2);
		setTitle("GomokuSettings");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	//creates a panel with two buttons for the menu frame
	public void createPanel()
	{
		JButton obFifteen = new JButton("15x15");
		JButton obNineteen = new JButton("19x19");
		
		JButton Players1 = new JButton("One Player");
		Players1.setBackground(Color.cyan);
		JButton Players2 = new JButton("Two Player");
		Players2.setBackground(Color.LIGHT_GRAY);

		JPanel obMenu = new JPanel();
		
		
		Players1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
				Players =2;
				Players1.setBackground(Color.cyan);
				Players2.setBackground(Color.LIGHT_GRAY);
			}
		});
		
		Players2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
				Players2.setBackground(Color.cyan);
				Players1.setBackground(Color.LIGHT_GRAY);
				Players =1;
			}
		});
		obFifteen.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
				GameController Game = new GameController(15,Players);
			}
		});
		
		obNineteen.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
				GameController Game = new GameController(19,Players);

			}
		});
		
		obMenu.add(Players1);
		obMenu.add(Players2);
		obMenu.add(obFifteen);
		obMenu.add(obNineteen);
		add(obMenu);
	}
	
	
}
