
public class AIController
{
	String AIchoice;

	public  String AIController(int [] userInput, int [][]naBoard)
	{
		int currentNumber= naBoard[userInput[0]][userInput[1]];
		return rowCheck(userInput, naBoard, currentNumber);
	}

	private String rowCheck(int[] userInput, int [][] naBoard,int currentNumber) 
	{
		int check= userInput[0];
		int count = 0;

		while(naBoard[check][userInput[1]]==currentNumber)
		{
			count++;
			check++;
			System.out.println(naBoard[check+1][userInput[1]]);
			if(count ==3 && naBoard[check+1][userInput[1]]!=2)		
			{
				AIchoice = Integer.toString(check) +":"+ Integer.toString(userInput[1]);
				return AIchoice;
			}
		}
		check--;
		count=0;
		while(naBoard[check][userInput[1]]==currentNumber)
		{
			count++;
			check--;
			System.out.println(naBoard[check-1][userInput[1]]);
			if(count ==3 && naBoard[check-1][userInput[1]]!=2)		
			{
				AIchoice = Integer.toString(check) +":"+ Integer.toString(userInput[1]);
				return AIchoice;
			}
		}
		return colCheck(userInput, naBoard, currentNumber);
	}


	private String colCheck(int[] userInput, int [][] naBoard,int currentNumber) 
	{	
		int check= userInput[1];
		int count = 0;
		while(naBoard[userInput[0]][check]==currentNumber)
		{
			count++;
			check++;
			if(count ==3 && naBoard[userInput[0]][check+1]!=2)		
			{
				AIchoice = Integer.toString(userInput[0]) +":"+ Integer.toString(check);
				return AIchoice;
			}

		}
		check--;
		count=0;

		while(naBoard[userInput[0]][check]==currentNumber)
		{
			count++;
			check--;
			if(count ==3 && naBoard[userInput[0]][check-1]!=2)		
			{
				AIchoice = Integer.toString(userInput[0]) +":"+ Integer.toString(check);
				return AIchoice;
			}
		}
		return MajorDiagonal(userInput, naBoard, currentNumber);
	}

	private String MajorDiagonal(int[] userInput, int[][] naBoard, int currentNumber)
	{
		int checkX= userInput[0];
		int checkY= userInput[1];
		int count = 0;
		while(naBoard[checkX][checkY]==currentNumber)
		{
			count++;
			checkX++;
			checkY++;
			if(count ==3 && naBoard[checkX][checkY]!=2)		
			{
				AIchoice = Integer.toString(checkX) +":"+ Integer.toString(checkY);
				return AIchoice;
			}

		}
		count=0;
		checkX--;
		checkY--;
		while(naBoard[checkX][checkY]==currentNumber)
		{
			count++;
			checkX--;
			checkY--;

			if(count ==3 && naBoard[checkX][checkY]!=2)		
			{
				AIchoice = Integer.toString(checkX) +":"+ Integer.toString(checkY);
				return AIchoice;
			}
		}
		return minorDiagonal(userInput, naBoard, currentNumber);
	}

	private String minorDiagonal(int[] userInput, int[][] naBoard, int currentNumber)
	{
		int checkX= userInput[0];
		int checkY= userInput[1];
		int count = 0;
		while(naBoard[checkX][checkY]==currentNumber)
		{
			count++;
			checkX++;
			checkY--;
			if(count ==3 && naBoard[checkX][checkY]!=2)
			{
				AIchoice = Integer.toString(checkX) +":"+ Integer.toString(checkY);
				return AIchoice;
			}
		}
		count=0;
		checkX--;
		checkY++;
		while(naBoard[checkX][checkY]==currentNumber)
		{
			count++;
			checkX--;
			checkY++;
			if(count ==3 && naBoard[checkX][checkY]!=2)
			{
				AIchoice = Integer.toString(checkX) +":"+ Integer.toString(checkY);
				return AIchoice;
			}

		}
		return Integer.toString((int) (Math.random()*naBoard.length))+":"+Integer.toString((int)(Math.random()*naBoard.length));	
	}
}
