import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

public class Listeners implements ActionListener  {

	public static class ClickListener15 implements ActionListener  {
		
		public void actionPerformed(ActionEvent e) {
			JFrame Game = new GameController(5);
		}
	}
	public static class ClickListener19 implements ActionListener  {
		
		public void actionPerformed(ActionEvent e) {
			JFrame Game = new GameController(19);
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}


}
