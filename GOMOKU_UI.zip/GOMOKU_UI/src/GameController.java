import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class GameController extends JFrame implements ActionListener
{
	int [][] board = new int[15][15];

	private JButton[][] Confirm;
	private JButton button;

	int [] User;
	int  Player = 2;
	
	
	public GameController(int Board_SIZE) 
	{
		createPanel(Board_SIZE);
		setSize(Board_SIZE*50,Board_SIZE*50);
		setTitle("Gomoku");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	private void createPanel(int BOARD_SIZE)
	{
		board = new int[BOARD_SIZE][BOARD_SIZE];

		Confirm = new JButton[BOARD_SIZE][BOARD_SIZE];
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(5,5,5,5));
		panel.setLayout(new GridLayout(BOARD_SIZE,BOARD_SIZE));		

		for(int i=0;i<Confirm.length;i++)
		{
			for(int j = 0;j<Confirm[i].length;j++)
			{
				button = Confirm[i][j];
				button = new JButton();
				button.setName(String.valueOf(i)+":"+String.valueOf(j));
				button.addActionListener(this);
				
				panel.add(button);
			}
		}
		add(panel);
	}
 
	public void actionPerformed(ActionEvent event)
	{
		Player = GomokuGameLogic.PlayerToken(Player);
		//Updates button colors and removes listener
		if(Player == 1)
		{
			((JButton) event.getSource()).setBackground(Color.BLACK);
			((JButton) event.getSource()).removeActionListener(this);
		}
		else
		{
			((JButton) event.getSource()).setBackground(Color.RED);
			((JButton) event.getSource()).removeActionListener(this);
		}
		//gets coordinates from button name
		String [] UserString = (((JButton) event.getSource()).getName().split(":"));
		User = new int[UserString.length];
		for(int i = 0;i<UserString.length;i++)
		{
			User[i] =Integer.parseInt(UserString[i]);
		}
		//updates board and checks for win condition
		board = GomokuGameLogic.Update(board, User, Player);
		GomokuGameLogic.PrintBoard(board);
		
		if(GomokuGameLogic.WinCondition(GomokuGameLogic.ColCheck(board), GomokuGameLogic.RowCheck(board), GomokuGameLogic.DiagCheck(board)))
		{
			GameWin();
		}
		//prints coordinates to console for debugging
		System.out.println(((JButton) event.getSource()).getName());
	}
	private void GameWin()
	{
		JFrame WinFrame = new JFrame(); 
		JOptionPane.showMessageDialog(WinFrame,"Player "+Player+ " Wins");
		System.out.print("Player "+Player+ " Wins");
		setVisible(false);
	}
	public static void StaleMate()
	{
		JFrame WinFrame = new JFrame(); 
		JOptionPane.showMessageDialog(WinFrame,"Draw");
		System.out.print("Draw");
	}
}

