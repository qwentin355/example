import java.awt.event.ActionListener;

import javax.swing.*;

public class OptionsFrame extends JFrame {
	private int Frame_SIZE = 400;
	public OptionsFrame() 
	{
		createPanel();
		setSize(Frame_SIZE,Frame_SIZE/3);
		setTitle("GomokuSettings");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	public void createPanel()
	{
		ActionListener fifteen = new Listeners.ClickListener15();
		ActionListener ninteen = new Listeners.ClickListener19();
		
		JButton Fifteen = new JButton("15x15");
		JButton Nineteen = new JButton("19x19");

		JPanel Menu = new JPanel();
		
		Fifteen.addActionListener(fifteen);
		Nineteen.addActionListener(ninteen);
		
		Menu.add(Fifteen);
		Menu.add(Nineteen);
		add(Menu);
	}

	
}
