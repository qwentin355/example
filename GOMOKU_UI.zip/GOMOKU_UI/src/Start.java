
import javax.swing.JFrame;

public class Start  {
	public static void main(String[] args) {
		JFrame frame = new OptionsFrame();
	}
}
