
public class GomokuGameLogic {

	/* checks is 5 in a row is found either vertically, Horizontally, or Diagonally
	 * if any of these are true, then the game ends
	 * @checks for win conditions
	 */
	public static boolean WinCondition(boolean X, boolean Y, boolean Diagon)
	{
		if(X==false&&Y==false&&Diagon==false)
			return false;
		else
			return true;
	}

	/*Column Check
	 * @Checks the columns for 5 sequential inputs that are equal
	 */
	public static boolean ColCheck(int[][]board)
	{
		for(int i = 0;i<board.length;i++)
		{
			int count =0;//resets count when moving to a new column
			int currentNumber=board[0][i];//sets count to the top of the new column
			for(int j = 0; j<board[i].length;j++)//sequences down the column
			{
				if(board[j][i]==currentNumber && currentNumber !=0)
				{
					count++;
					if(count == 5)
					{
						return true;
					}
				}
				else
				{
					count=1;
				}
				currentNumber=board[j][i];//updates the previously checked number
			}
		}
		return false;
	}
	/*Row Check
	 * @Checks Rows for sequence of 5
	 */
	public static boolean RowCheck(int[][]board)
	{
		int nStalemate=0;
		for(int i = 0;i<board.length;i++)
		{
			int count =0;
			int currentNumber=board[i][0];
			
			for(int j = 0; j<board[i].length;j++)
			{
				if(board[i][j]==0)
				{
					nStalemate++;
				}
				if(board[i][j]==currentNumber && currentNumber!=0)
				{
					count++;
					if(count == 5)
					{
						return true;
					}
				}
				else
				{
					count=1;
				}
				currentNumber= board[i][j];
			}
		}
		if(nStalemate==0)
		{
			GameController.StaleMate();
		}
		return false;
	}
	/*Diagonal Check
	 * @Checks diagonals for sequence of 5
	 */
	public static boolean DiagCheck(int[][]board)
	{
		int count = 0;
		int currentNumber = board[0][0];
		//diagonal
		for (int i =0;i<board.length*2-1;i++)
		{ 
			int j = i;
			int k = 0;
			if(i>board.length-1)
			{
				j=board.length-1;
				k=i-j;
			}
			count=0;  
			currentNumber = board[j][k];
			for(int l = k;j>=l;j--, k++)
			{
				if(board[j][k]==currentNumber && currentNumber!=0)
				{
						count++;
						if(count==5)
						{
							return true;
						}		
				}
				else
				{
					count =1;
				}
				currentNumber = board[j][k];
			}
		}
		//AntiDiagonal
		for (int i =0;i<board.length*2-1;i++)
		{ 
			int j = board.length-1;
			int k = i;
			if(i>board.length-1)
			{			
				k= board.length-1;
				j=k*2-i;
			}
			count=0;  
			currentNumber = board[j][k];
			for(int l = i-k;k>=l;j--, k--)
			{
				if(board[j][k]==currentNumber && currentNumber!=0)
				{
						count++;
						if(count==5)
						{
							return true;
						}		
				}
				else
				{
					count =1;
				}
				currentNumber = board[j][k];
			}
		}
		return false;
	}
	/* Board Updater
	 * @Updates the board array with users input
	 */
	public static int[][] Update(int[][]board,int[] User,int Player)
	{
		board[User[0]][User[1]]=Player;//uses 1-15 instead of 0-14
		return board;

	}
	/*Player selector
	 * @Passes a virtual token between players
	 */
	public static int PlayerToken(int Player)
	{//passes the turn
		if(Player == 1)
			return 2;
		else
			return 1;
	}
	
	/*Prints board in console
	 * @Console debugging board
	 */
	public static void PrintBoard(int[][] board)
	{
		for(int i=0;board.length>i;i++)
		{
			if(i>9)
			{ 
				System.out.print("  "+ i);//prints top index
			}
			else
				System.out.print("   "+ i);
		}
		System.out.println();
		for(int i=0;board.length>i;i++)
		{
			if(i>9)
			{
				System.out.print(i + " | ");  //prints side index
			}
			else
				System.out.print(i + "  | ");
			//prints the board
			for(int j=0;board[i].length>j;j++)
			{
				if(board[i][j]!=0)
				{
					System.out.print(board[i][j]+" | ");
				}
				else
				{
					System.out.print("  | ");
				}
			}
			//prints horizontal gridlines
			System.out.print("\n    ");
			for(int k=0;k<board.length;k++)
			{
				System.out.print("----");
			}
			System.out.print("\n");
		}
	}
}

